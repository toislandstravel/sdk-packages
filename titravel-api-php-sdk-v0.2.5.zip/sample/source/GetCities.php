<?php
/**
 * Prints out the highligted PHP code sample
 */
?>
<html>
<head>
<meta charset="utf-8">
<title>Get cities sample code</title>
</head>
<body>
    <h1>Get cities sample code</h1>
    <pre><?php highlight_file('../api/'.basename(__FILE__)); ?></pre>
    <a href='../index.htm'>Back</a>
</body>
</html>