<?php
/**
 * Prints out the highligted PHP code sample
 */
?>
<html>
<head>
<meta charset="utf-8">
<title>Get attributes sample code</title>
</head>
<body>
    <h1>Get attributes sample code</h1>
    <pre><?php highlight_file('../api/'.basename(__FILE__)); ?></pre>
    <a href='../index.htm'>Back</a>
</body>
</html>