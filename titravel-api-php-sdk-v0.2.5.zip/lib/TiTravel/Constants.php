<?php
namespace TiTravel;

class Constants
{
    const SDK_NAME = 'sdk-php';
    const SDK_VERSION = '0.2.5';

    const API_LIVE_ENDPOINT = 'https://www.adrianet.org/?a=xml_api&v=4&format=xml';
}